﻿Friend Interface IConfigurationRoot
    Function GetConnectionString(nombreConexion As String) As String
End Interface
