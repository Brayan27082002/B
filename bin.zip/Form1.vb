﻿Imports System.Data.SqlClient

Public Class Form1

    Private intentosFallidos As Integer = 0

    Private Sub buttonIniciarSesion_Click(sender As Object, e As EventArgs) Handles buttonIniciarSesion.Click
        Dim nombreUsuario As String = textBoxUsuario.Text
        Dim contraseña As String = textBoxContraseña.Text

        Dim nombreConexion As String = "Server=DESKTOP-5IUTMSG;Database=sistema;Integrated Security=True;"

        Using conexion As New SqlConnection(nombreConexion)
            conexion.Open()

            Using comando As New SqlCommand("SELECT COUNT(*) FROM Usuarios WHERE NombreUsuario = @NombreUsuario AND ClaveCifrada = @ClaveCifrada", conexion)
                comando.Parameters.AddWithValue("@NombreUsuario", nombreUsuario)
                comando.Parameters.AddWithValue("@ClaveCifrada", contraseña)

                Dim resultado As Integer = CInt(comando.ExecuteScalar())

                If resultado > 0 Then

                    intentosFallidos = 0

                    MessageBox.Show("Inicio de sesión exitoso.")

                Else

                    intentosFallidos += 1

                    If intentosFallidos >= 3 Then
                        MessageBox.Show("Has excedido el número máximo de intentos fallidos. Tu cuenta ha sido bloqueada.")
                    Else
                        MessageBox.Show("Inicio de sesión fallido. Verifica tu nombre de usuario y contraseña.")
                    End If
                End If
            End Using
        End Using
    End Sub
End Class

