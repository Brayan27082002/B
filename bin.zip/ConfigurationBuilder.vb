﻿Friend Class ConfigurationBuilder
    Public Sub New()
    End Sub

    Friend Sub AddJsonFile(v As String)
        Throw New NotImplementedException()
    End Sub

    Friend Function Build() As IConfigurationRoot
        Throw New NotImplementedException()
    End Function
End Class
